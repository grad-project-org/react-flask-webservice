-- MySqlBackup.NET 2.0.9.2
-- Dump Time: 2021-01-09 00:54:16
-- --------------------------------------
-- Server version 5.7.26-log MySQL Community Server (GPL)

-- 
-- Create schema nodejslogin1
-- 

CREATE DATABASE IF NOT EXISTS `nodejslogin1` /*!40100 DEFAULT CHARACTER SET utf8 */;
Use `nodejslogin1`;



/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- 
-- Definition of users
-- 

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `created` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table users
-- 

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users`(`id`,`first_name`,`last_name`,`email`,`password`,`created`) VALUES
(1,'Jhon','Doe','lol@lol.com','20D0247367DFB2321C23420CF74D2184','2021-01-08 20:15:12'),
(2,'Ana','Swain','l@l.com','0F6D407C2BADB71D0ED829D3F7C9881B','2021-01-08 21:20:02'),
(4,'David','Beckam','david@beckam.com','124CA24877E9C4973AC365AB2FBB0DCB','2021-01-08 23:20:01'),
(5,'Gerard','Pique','gpique@gmail.com','88F8D2EAE0DF674134535580A4E67A35','2021-01-09 00:34:09');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- 
-- Dumping procedures
-- 

DROP PROCEDURE IF EXISTS `getuser`;
DELIMITER |
CREATE PROCEDURE `getuser`(
in _email varchar(100),
in _password text
)
begin
	select first_name ,last_name ,aes_decrypt(unhex(password), email), email, created from users u 
	where email = _email and password = hex(aes_encrypt(_password, _email));
end |
DELIMITER ;

DROP PROCEDURE IF EXISTS `userinsert`;
DELIMITER |
CREATE PROCEDURE `userinsert`(
IN _first_name VARCHAR(100),
in _last_name varchar(100),
in _email varchar(100),
in _password text
)
BEGIN
  	INSERT INTO nodejslogin1.users
	(first_name, last_name, email, password, created)
	VALUES(_first_name , _last_name , _email , hex(aes_encrypt(_password, _email)), now());
END |
DELIMITER ;


/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


-- Dump completed on 2021-01-09 00:54:16
-- Total time: 0:0:0:0:249 (d:h:m:s:ms)
